const express = require('express');
const router = express.Router();
const async = require('async');
const moment = require('moment');
const XLSX = require('xlsx');
const multer = require('multer');
const fs = require('fs');
const tempfile = require('tempfile');
const util = require('util')

const Ledgex = require('../libs/ledgex')();
const Input = Ledgex.Input;
const Division = Ledgex.Division;
const Field = Ledgex.Field;
const FieldName = Ledgex.FieldName;
const FieldRegex = Ledgex.FieldRegex;

// Allocate space in memory for uploaded files
const memoryStorage = multer.memoryStorage();

// Filter function for allowing only xlsx file
const excelFilter = function(req, file, cb) {
  if (!file.originalname.match(/\.(xlsx)$/)) {
    req.fileValidationError = 'Only excel files are allowed!';
    return cb(new Error('Only excel files are allowed!'), false);
  }
  cb(null, true);
};

// Build a multer middleware for handling multipart/form-data
// Use memory storage and excel file filter
const multerMiddleware = multer({ storage: memoryStorage, fileFilter: excelFilter });

// Render app home page
router.get('/', function(req, res) {
  res.render('index');
});


// multerMiddleware.single("ledger") for handle input file
router.post('/upload', multerMiddleware.single('ledger'), (req, res) => {
  req.setTimeout(360000);

  // Create Ledgex library input with the incoming file buffer
  let ledgexInput = new Input(Input.Types.Buffer, req.file.buffer);

  // Setup library options
  let ledgexOptions = {
    invoiceManyCustomers: true, // A same invoice number could be allocated to many customers
    defaultDivision: "ENT-PST"
  };

  // Instantiate library with input and options
  let ledgex = new Ledgex(ledgexInput, ledgexOptions);

  // Instancer une division pour le service "ISTNA" et ajouter des règles de
  // reconnaissances qui permettront d'attribuer
  let istnaDivision = new Division("ISTNA", true);
  istnaDivision.recognizer.addRule(new Field(FieldName.INVOICE_NUMBER), new FieldRegex("regex", "test", /istna/i));
  istnaDivision.recognizer.addRule(new Field(FieldName.LIBELLE), new FieldRegex("regex", "test", /istna/i));

  let ardanDivision = new Division("ARDAN", true);
  ardanDivision.recognizer.addRule(new Field(FieldName.LIBELLE), new FieldRegex("regex", "test", /ardan/i));
  //ardanDivision.recognizer.addRule(new Field(FieldName.INVOICE_NUMBER), new FieldRegex("regex", "test", /da\d|rum\d/i));
  ardanDivision.recognizer.addRule(new Field(FieldName.INVOICE_NUMBER), new FieldRegex("regex", "test", /da\d|idf\d/i));

  let partnerDivision = new Division("PARTENARIAT", true);
  partnerDivision.recognizer.addRule(new Field(FieldName.INVOICE_NUMBER), new FieldRegex("regex", "test", /drit\d|pt\d/i));

  let labsDivision = new Division("LABSDN", true);
  labsDivision.recognizer.addRule(new Field(FieldName.INVOICE_NUMBER), new FieldRegex("regex", "test", /labsdn/i));
  labsDivision.recognizer.addRule(new Field(FieldName.LIBELLE), new FieldRegex("regex", "test", /GESICC@/i));
  labsDivision.recognizer.addRule(new Field(FieldName.LIBELLE), new FieldRegex("regex", "test", /labsdn/i));

  let opcoDivision = new Division("OPCO", true);
  opcoDivision.recognizer.addRule(new Field(FieldName.CUSTOMER_NAME), new FieldRegex("array", "test", ["OPCO", "OPCA", "ADEFIM", "OPCAIM", "AFDAS", "AGEFOS", "ANFA", "FAFIH", "FAFSE", "AKTO", "FONGECIF", "FORCO", "UNIFORMATION", "CONSTRUCTYS", "OTIS", "UNIFAFBRUGES", "INTERGROS", "INTERGROSNOISY", "FAFTT", "FAFIECPARIS", "DEFISAINTMANDE"]));

  ledgex.insertDivision(istnaDivision);
  ledgex.insertDivision(ardanDivision);
  ledgex.insertDivision(partnerDivision);
  ledgex.insertDivision(labsDivision);
  ledgex.insertDivision(opcoDivision);


  async.waterfall([
    // Lire et traîter les données présente dans le grand livre
    (done) => {
      ledgex.parse(() => {
        console.log("Ledgex fully parsed");
        done();
      });
    },

    // Build Excel
    (done) => {
      async.parallel([
        // Grouped
        (next) => {
          ledgex.generateWorkbook({ lean: false }, (wb) => {
            next(null, wb);
          });
        },
        // Lean
        (next) => {
          /*ledger.generateWorkbook({ lean: true }, (wb) => {
            next(null, wb);
          });*/
          next();
        }
      ], (err, results) => {
        if (err) console.log(err);
        done(null, results[0]);
      });
    },
  ], (err, wb_grouped) => {
    console.log(err);
    return res.status(200).json({ workbook: wb_grouped });
  });
});


module.exports = router;

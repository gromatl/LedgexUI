'use strict';

function loadJS(filename){
  var fileref = document.createElement('script');
  fileref.setAttribute("type","text/javascript");
  fileref.setAttribute("src", filename);
  document.getElementsByTagName("head")[0].appendChild(fileref)
}

// Generate link and launch download
function downloadOutput(data, outputName, outputType){
  // pass your byte response to this constructor
  var bytes = new Uint8Array(data);
  // change resultByte to bytes
  var blob = new Blob([bytes], { type: outputType });
  // Create dynamic link and simulate click for launch download
  var link = document.createElement('a');
  link.href = window.URL.createObjectURL(blob);
  link.download = outputName;
  link.click();
}

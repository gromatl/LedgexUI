$(function (){

  var drEvent = $('.dropify').dropify({
    messages: {
      default: 'Glissez-déposez un fichier ici ou cliquez',
      replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
      remove:  'Supprimer',
      error:   'Désolé, le fichier trop volumineux'
    },
    allowedFileExtensions: "xlsx"
  });


  drEvent.on('dropify.beforeClear', function(event, element){
    return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
  });

  drEvent.on('dropify.afterClear', function(event, element){
    console.log('File deleted');
  });

  drEvent.on('dropify.errors', function(event, element){
    console.log('Has Errors');
  });

  $('input:file').on('change', function () {
    var file = this.files[0];
    if (file.type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"){
      var formData = new FormData();
      formData.append("ledger", file);
      console.log(formData);

      $.ajax({
        url: '/upload',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        beforeSend: function( xhr ) {
          Swal.fire({
            title: 'Ledgex',
            html: 'Votre livre comptable est en cours d\'anlyse, merci de bien vouloir patienter quelques secondes...',
            allowOutsideClick: false,
            onBeforeOpen: function() {
              Swal.showLoading()
            }
          });
        }
      }).done(function(data){
        console.log(data);
        Swal.fire({
          title: 'L\'analyse est terminée !',
          icon: 'success'
        });
        if (data.workbook) downloadOutput(data.workbook.data, `${moment().format("DDMMYYYY")}-S${moment().week()}-GLT-VBO.xlsx`, "application/xlsx");
        //if (data.workbook_lean) downloadOutput(data.workbook_lean.data, `${moment().format("DDMMYYYY")}-S${moment().week()}-GLT-LEAN.xlsx`, "application/xlsx");
      });
    }
  });
});

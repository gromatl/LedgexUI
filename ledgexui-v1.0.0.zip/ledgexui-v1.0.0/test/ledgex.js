
const Ledgex = require('../libs/ledgex')();
const Field = Ledgex.Field;
const FieldName = Ledgex.FieldName;
const FieldRegex = Ledgex.FieldRegex;
const Customer = Ledgex.Customer;
const Division = Ledgex.Division;
const Operation = Ledgex.Operation;
const Invoice = Ledgex.Invoice;
const EventChannel = Ledgex.EventChannel;
const EventCode = Ledgex.EventCode;
const Input = Ledgex.Input;

const fs = require('fs');


let options = {
  invoiceManyCustomers: true,
  defaultDivision: "ENT-PST"
}
const ledger = new Ledgex(new Input(Input.Types.File, `${process.cwd()}/test/PREP.xlsx`), options);

/*
Setup division
*/
let istnaDivision = new Division("ISTNA");
istnaDivision.recognizer.addRule(new Field(FieldName.INVOICE_NUMBER), new FieldRegex("regex", "test", /istna/i));
istnaDivision.recognizer.addRule(new Field(FieldName.LIBELLE), new FieldRegex("regex", "test", /istna/i));

let ardanDivision = new Division("ARDAN");
ardanDivision.recognizer.addRule(new Field(FieldName.LIBELLE), new FieldRegex("regex", "test", /ardan/i));
ardanDivision.recognizer.addRule(new Field(FieldName.INVOICE_NUMBER), new FieldRegex("regex", "test", /da\d|rum\d/i));

let partnerDivision = new Division("PARTENARIAT");
partnerDivision.recognizer.addRule(new Field(FieldName.INVOICE_NUMBER), new FieldRegex("regex", "test", /drit\d|pt\d/i));

let labsDivision = new Division("LABSDN");
labsDivision.recognizer.addRule(new Field(FieldName.INVOICE_NUMBER), new FieldRegex("regex", "test", /labsdn/i));
labsDivision.recognizer.addRule(new Field(FieldName.LIBELLE), new FieldRegex("regex", "test", /GESICC@/i));

let opcoDivision = new Division("OPCO");
opcoDivision.recognizer.addRule(new Field(FieldName.CUSTOMER_NAME), new FieldRegex("array", "test", ["OPCO", "OPCA", "ADEFIM", "OPCAIM", "AFDAS", "AGEFOS", "ANFA", "FAFIH", "FAFSE", "AKTO", "FONGECIF", "FORCO", "UNIFORMATION", "CONSTRUCTYS", "OTIS"]));


ledger.insertDivision(istnaDivision);
ledger.insertDivision(ardanDivision);
ledger.insertDivision(partnerDivision);
ledger.insertDivision(labsDivision);
ledger.insertDivision(opcoDivision);

ledger.parse();


ledger.generateWorkbook({ lean: false }, (wb) => {
  fs.writeFile(`${__dirname}/Test-Ouput.xlsx`, wb, (err) => {
    console.log(err);
  });
});
//console.log(wb);

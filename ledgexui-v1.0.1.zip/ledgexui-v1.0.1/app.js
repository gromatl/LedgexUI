/*
*
* LEDGEX
* Version :
*
* Licence :
*
* Copyright : GROMAT Luidgi
*
* Contact : gromat.luidgi@gmail.com
*
*/

const httpErrors = require('http-errors');
const express = require('express');
const path = require('path');
const compression = require('compression');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const moment = require('moment');
moment.locale('fr');

var app = express();
app.locals.moment = moment;

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Compresser toutes les réponses, fichiers statiques inclus
app.use(compression({ threshold: 0 }));

// Les requêtes POST & PUT doivent être converti en JSON
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));

app.use(express.static(path.join(__dirname, 'public')));

// Logger uniquement toutes les requêtes à destination des routes (controller)
app.use(morgan('tiny'));

app.use('/', require('./routes/index'));

console.log("Ledgex UI est désormais actif");

// Aucune route trouvée, forward la requête vers httpErrors
app.use(function(req, res, next) {
  next(httpErrors(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;

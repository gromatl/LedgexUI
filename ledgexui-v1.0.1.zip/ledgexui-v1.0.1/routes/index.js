const config = require("config");
const express = require('express');
const router = express.Router();
const async = require('async');
const moment = require('moment');
const XLSX = require('xlsx');
const multer = require('multer');
const fs = require('fs');
const tempfile = require('tempfile');
const util = require('util');

const Ledgex = require('../libs/ledgex')();
const Input = Ledgex.Input;
const Division = Ledgex.Division;
const Field = Ledgex.Field;
const FieldName = Ledgex.FieldName;
const FieldRegex = Ledgex.FieldRegex;

// Allocate space in memory for uploaded files
const memoryStorage = multer.memoryStorage();

// Filter function for allowing only xlsx file
const excelFilter = function(req, file, cb) {
  if (!file.originalname.match(/\.(xlsx)$/)) {
    req.fileValidationError = 'Only excel files are allowed!';
    return cb(new Error('Only excel files are allowed!'), false);
  }
  cb(null, true);
};

// Build a multer middleware for handling multipart/form-data
// Use memory storage and excel file filter
const multerMiddleware = multer({ storage: memoryStorage, fileFilter: excelFilter });

// Render app home page
router.get('/', function(req, res) {
  res.render('index');
});


// multerMiddleware.single("ledger") for handle input file
router.post('/analyze', multerMiddleware.single('ledger'), (req, res) => {
  // Extent default timeout for this request
  // This allow low perfomance systeme to have enought time to treat a large file
  req.setTimeout(360000);

  // Load external configurations
  let ledgexConfig = null;
  let divisionConfig = null;

  if (config.has('Ledgex')) ledgexConfig = config.get('Ledgex');
  if (config.has('Divisions')) divisionConfig = config.get('Divisions');

  // Additional parameters
  var lean = (req.body.lean === 'true');
  var lock = (req.body.protected === 'true');

  // Create Ledgex library input with the incoming file buffer
  let ledgexInput = new Input(Input.Types.Buffer, req.file.buffer);

  // Setup library options
  let ledgexOptions = {};

  // First sheet default name
  if (ledgexConfig.has('globalDivisionName')){
    ledgexOptions.defaultDivision = ledgexConfig.get('globalDivisionName');
  }

  //
  if (ledgexConfig.has('invoiceNumberForManyCustomers')){
    ledgexOptions.invoiceManyCustomers = ledgexConfig.get('invoiceNumberForManyCustomers');
  }

  // Instantiate library with input and options
  let ledgex = new Ledgex(ledgexInput, ledgexOptions);

  // Check division configuration
  try {
    if (divisionConfig && divisionConfig.length > 0){
      for (var i = 0; i < divisionConfig.length; i++){
        if (!divisionConfig[i].name){
          throw Error("Invalid division name");
        } else if (!divisionConfig[i].rules || divisionConfig[i].rules.length == 0){
          throw Error("No rules set for division");
        }

        let division = new Division(divisionConfig[i].name);
        for (var z = 0; z < divisionConfig[i].rules.length; z++){
          let rule = divisionConfig[i].rules[z];
          let pattern = rule.pattern;
          if (rule.type === "regex"){
            pattern =  new RegExp(rule.pattern, rule.flag);
          }
          division.recognizer.addRule(new Field(rule.fieldName), new FieldRegex(rule.type, rule.operation, pattern));
        }
        ledgex.insertDivision(division);
      }
    }
  } catch(err){
    console.log(err);
    return res.status(500).json(err);
  }


  async.waterfall([
    // Lire et traîter les données présente dans le grand livre
    (done) => {
      ledgex.parse(() => {
        //console.log("Ledgex fully parsed");
        done();
      });
    },

    // Build Output
    (done) => {
      ledgex.generateWorkbook({ lean: lean, lock: lock }, (wb) => {
        done(null, wb);
      });
    },
  ], (err, wb) => {
    if (err){
      console.log(err);
      return res.status(500).json(err);
    }

    // Print memory usage after the parse and generation of new ledger
    if (process.env.NODE_ENV === 'development'){
      const used = process.memoryUsage();
      for (let key in used) {
        console.log(`${key} ${Math.round(used[key] / 1024 / 1024 * 100) / 100} MB`);
      }
    }

    return res.status(200).json({ workbook: wb });
  });
});


module.exports = router;

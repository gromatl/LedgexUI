$(function (){

  /*
  * Load dropify pluggins for allowing file upload
  */
  var dropify = $('.dropify').dropify({
    messages: {
      default: 'Zone de transfert',
      replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
      remove:  'Supprimer',
      error:   'Le format de votre fichier n\'est pas valide'
    },
    allowedFileExtensions: "xlsx"
  });

  /*
  * Event is raised after clearing dropify file
  */
  dropify.on('dropify.afterClear', function(event, element){
    console.log('File deleted');
  });

  /*
  * Event is raised when error is detected by dropify
  */
  dropify.on('dropify.errors', function(event, element){
    console.log('Has Errors');
  });

  /*
  * Listen for change in upload zone
  * If the input is valid, transfer the file to the server for treatment
  */
  $('input:file').on('change', function () {
    var file = this.files[0];
    //console.log(file);
    if (file.type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"){
      var outputFormatSelect = document.getElementById("output-format-select");
      var outputFormat = outputFormatSelect.options[outputFormatSelect.selectedIndex].value;

      var protectionSelect = document.getElementById("protection-select");
      var isProtected = protectionSelect.options[protectionSelect.selectedIndex].value;

      var formData = new FormData();
      formData.append("ledger", file);
      formData.append("lean", outputFormat);
      formData.append("protected", isProtected);

      $.ajax({
        url: '/analyze',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        beforeSend: function( xhr ) {
          Swal.fire({
            icon: 'info',
            title: 'Ledgex',
            html: 'Votre livre comptable est en cours d\'analyse, merci de bien vouloir patienter quelques secondes...',
            allowOutsideClick: false,
            onBeforeOpen: function() {
              Swal.showLoading()
            }
          });
        }
      }).done(function(data){
        //console.log(data);
        Swal.fire({
          title: 'L\'analyse est terminée !',
          icon: 'success'
        });
        clearDropify();
        if (data.workbook) downloadOutput(data.workbook.data, `${moment().format("DDMMYYYY")}-S${moment().week()}-GLT-VBO.xlsx`, "application/xlsx");
      }).fail(function(data){
        console.log(data);
        Swal.fire({
          title: 'Oups, une erreur c\'est produite',
          icon: 'error'
        });
        clearDropify();
      });
    }
  });
});

function clearDropify(){
  $('.dropify-clear').click();
}
